from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, DateType, StringType, FloatType
from pyspark.sql.functions import stddev, col
from pyspark.sql import functions as F

schema = StructType([
    StructField("date",DateType(),True),			
    StructField("time",StringType(),True),	
    StructField("global_active_power",FloatType(),True),	
    StructField("global_reactive_power",FloatType(),True),	
    StructField("voltage",FloatType(),True),	
    StructField("global_intensity",FloatType(),True),	
    StructField("sub_metering_1",FloatType(),True),	
    StructField("sub_metering_2",FloatType(),True),	
    StructField("sub_metering_3",FloatType(),True),	
])
spark = SparkSession.builder.appName("HW1").getOrCreate()
df = spark.read.csv("household_power_consumption.txt",sep=';',header=True, schema=schema)

#Q1-Q3:
columns = ['global_active_power','global_reactive_power','voltage','global_intensity']
filter_condition = (
    F.col(columns[0]).cast("float").isNotNull() &
    F.col(columns[1]).cast("float").isNotNull() &
    F.col(columns[2]).cast("float").isNotNull() &
    F.col(columns[3]).cast("float").isNotNull()
)

max_list = []
min_list = []
count_list = []
mean_list = []
stddev_list = []
normaled = []
df_selected=df.select(columns)
df_selected = df_selected.filter(filter_condition)

for col in columns:
    max_n = df_selected.agg({col:'max'}).alias(f"max_{col}").collect()[0][0]
    max_list.append(max_n)
    min_n = df_selected.agg({col:'min'}).alias(f"min_{col}").collect()[0][0]
    min_list.append(min_n)
    count_n = df_selected.agg(F.count(col)).collect()[0][0]
    count_list.append(count_n)
    mean_n = df_selected.agg(F.mean(col)).collect()[0][0]
    mean_list.append(mean_n)
    stddev_n = df_selected.agg(stddev(col)).collect()[0][0]
    stddev_list.append(stddev_n)
    normal_string = f"normalized_{col}"
    normaled.append(normal_string)
    df_selected = df_selected.withColumn(normal_string,(F.col(col) - F.lit(min_n)/(F.lit(max_n) - F.lit(min_n))))

#Q1:
data1 = list(zip(max_list,min_list,count_list))
df_1 = spark.createDataFrame(data1,["max","min","count"])
df_1.show()

#Q2:
data2 = list(zip(mean_list,stddev_list))
df_2 = spark.createDataFrame(data2,["mean","stddev"])
df_2.show()

#Q3:
df_selected = df_selected.select(normaled)
df_selected_str = df_selected.select([F.col(c).cast("string") for c in df_selected.columns])
# Save the DataFrame as a text file
df_selected_str.coalesce(1).write.format("csv").option("header", "true").mode("overwrite").save("hw0_output.txt")









